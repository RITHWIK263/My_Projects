import React, { Component } from 'react';

export default class ShowEmployees extends Component {
  constructor() {
    super();
    this.state = {
      employees: [
        { empId: 101, empName: 'Harsha', salary: 1212.12, gender: 'Male', doj: '12-22-2020', emailId: 'harsha@gmail.com', password: '123' },
        { empId: 102, empName: 'Pasha', salary: 2323.23, gender: 'Male', doj: '11-23-2021', emailId: 'pasha@gmail.com', password: '123' },
        { empId: 103, empName: 'Venkat', salary: 3434.34, gender: 'Male', doj: '10-24-2022', emailId: 'venkat@gmail.com', password: '123' },
        { empId: 104, empName: 'Indira', salary: 4545.45, gender: 'Female', doj: '09-25-2020', emailId: 'indira@gmail.com', password: '123' },
        { empId: 105, empName: 'Deepika', salary: 5656.56, gender: 'Female', doj: '08-26-2021', emailId: 'deepika@gmail.com', password: '123' },
        { empId: 106, empName: 'Gopi', salary: 6767.67, gender: 'Male', doj: '07-27-2022', emailId: 'gopi@gmail.com', password: '123' }
      ]
    };
  }

  clearData = () => {
    this.setState({ employees: [] });
  };

  updateEmployee = (emp) => {
    console.log("UpdateEmployee:", emp);
  };

  deleteEmployee = (empId) => {
    console.log("DeleteEmployee:", empId);
  };

  render() {
    const { employees } = this.state;

    return (
      <div className="container" style={{ marginTop: "30px" }}>
        {employees.length > 0 ? (
          <>
            <h1 align="center">Employee Records</h1><br />
            <table className="table table-bordered table-sm table-hover table-striped">
              <thead className="bg-info text-white text-center">
                <tr>
                  <th>EmpId</th>
                  <th>EmpName</th>
                  <th>Salary</th>
                  <th>Gender</th>
                  <th>DateOfJoin</th>
                  <th>EmailId</th>
                  <th colSpan={2}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {employees.map((emp) => (
                  <tr key={emp.empId}>
                    <td>{emp.empId}</td>
                    <td>{emp.empName}</td>
                    <td>{emp.salary}</td>
                    <td>{emp.gender}</td>
                    <td>{emp.doj}</td>
                    <td>{emp.emailId}</td>
                    <td align="center"><button onClick={() => this.updateEmployee(emp)}>Edit</button></td>
                    <td align="center"><button onClick={() => this.deleteEmployee(emp.empId)}>Delete</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
            <br />
            <center>
              <button className="btn btn-primary" onClick={this.clearData}>Clear Data</button>
            </center>
          </>
        ) : (
          <h1 align="center" style={{ color: "red" }}>No Employee Records</h1>
        )}
      </div>
    );
  }
}