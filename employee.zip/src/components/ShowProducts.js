import React, { Component } from 'react';

export default class ShowProducts extends Component {
  constructor() {
    super();
    this.state = {
      role: localStorage.getItem("role"),
      products: [
        { prodId: 101, prodName: 'Nokia', price: 19999.99, description: 'No cost EMI Applicable for All Cards', imgurl: 'images/1001.jpg' },
        { prodId: 102, prodName: 'Samsung', price: 29999.99, description: 'No cost EMI Applicable for All Cards', imgurl: 'images/1002.jpg' },
        { prodId: 103, prodName: 'Motorola', price: 39999.99, description: 'No cost EMI Applicable for All Cards', imgurl: 'images/1003.jpg' },
        { prodId: 104, prodName: 'Apple', price: 49999.99, description: 'No cost EMI Applicable for All Cards', imgurl: 'images/1004.jpg' },
        { prodId: 105, prodName: 'Sony', price: 59999.99, description: 'No cost EMI Applicable for All Cards', imgurl: 'images/1005.jpg' },
        { prodId: 106, prodName: 'Google', price: 69999.99, description: 'No cost EMI Applicable for All Cards', imgurl: 'images/1006.jpg' }
      ],
      newProduct: { prodName: '', price: '', description: '', imgurl: '' }
    };
  }

  clearData = () => {
    this.setState({ products: [] });
  };

  addToCart = (prod) => {
    alert(`${prod.prodName} added to cart!`);
  };

  deleteProduct = (prodId) => {
    this.setState({
      products: this.state.products.filter(p => p.prodId !== prodId)
    });
  };

  handleProductInput = (e) => {
    const { name, value } = e.target;
    this.setState({
      newProduct: {
        ...this.state.newProduct,
        [name]: value
      }
    });
  };

  addProduct = () => {
    const { prodName, price, description, imgurl } = this.state.newProduct;
    if (!prodName || !price || !description || !imgurl) {
      alert("Please fill all product fields");
      return;
    }

    const newProd = {
      prodId: Date.now(),
      prodName,
      price: parseFloat(price),
      description,
      imgurl
    };

    this.setState({
      products: [...this.state.products, newProd],
      newProduct: { prodName: '', price: '', description: '', imgurl: '' }
    });
  };

  render() {
    const { products, role, newProduct } = this.state;

    const inputStyle = {
      padding: "8px",
      marginBottom: "10px",
      width: "100%",
      borderRadius: "4px",
      border: "1px solid #ccc"
    };

    const buttonStyle = {
      padding: "10px 20px",
      backgroundColor: "#007bff",
      color: "white",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer"
    };

    return (
      <div style={{ margin: "30px auto", maxWidth: "1000px", padding: "20px" }}>
        <h1 style={{ textAlign: "center", marginBottom: "20px" }}>Products</h1>

        <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center" }}>
          {products.map((prod) => (
            <div key={prod.prodId} style={{
              border: "1px solid #ccc", borderRadius: "8px", padding: "15px",
              margin: "10px", width: "300px", backgroundColor: "#fff"
            }}>
              <img src={prod.imgurl} alt={prod.prodName} style={{
                width: "100%", height: "180px", objectFit: "contain", backgroundColor: "#f8f9fa"
              }} />
              <h3>{prod.prodName}</h3>
              <p>{prod.description}</p>
              <p><b>Price:</b> ₹{prod.price}</p>
              <button onClick={() => this.addToCart(prod)} style={buttonStyle}>Add to Cart</button>
              {role === "employee" && (
                <button onClick={() => this.deleteProduct(prod.prodId)} style={{ ...buttonStyle, backgroundColor: "#dc3545", marginLeft: "10px" }}>
                  Delete
                </button>
              )}
            </div>
          ))}
        </div>

        {role === "employee" && (
          <div style={{ marginTop: "40px" }}>
            <h3>Add New Product</h3>
            <input name="prodName" placeholder="Product Name" value={newProduct.prodName} onChange={this.handleProductInput} style={inputStyle} />
            <input name="price" placeholder="Price" value={newProduct.price} onChange={this.handleProductInput} style={inputStyle} />
            <input name="description" placeholder="Description" value={newProduct.description} onChange={this.handleProductInput} style={inputStyle} />
            <input name="imgurl" placeholder="Image URL" value={newProduct.imgurl} onChange={this.handleProductInput} style={inputStyle} />
            <button onClick={this.addProduct} style={{ ...buttonStyle, backgroundColor: "#28a745" }}>Add Product</button>
          </div>
        )}
      </div>
    );
  }
}