import React, { useRef } from 'react';
import { useNavigate } from 'react-router-dom';

function Login() {
  const emailId = useRef();
  const password = useRef();
  const navigate = useNavigate();

  const loginSubmit = () => {
    const email = emailId.current.value.trim();
    const pass = password.current.value.trim();

    if (email === "HR" && pass === "HR") {
      localStorage.setItem("role", "admin");
      localStorage.setItem("user", "HR");
      alert("Admin Login Success");
      navigate("/home");
    } else {
      const user = JSON.parse(localStorage.getItem(email));
      if (user && user.password === pass) {
        localStorage.setItem("role", "employee");
        localStorage.setItem("user", email);
        alert("Employee Login Success");
        navigate("/home");
      } else {
        alert("Invalid Credentials");
      }
    }
  };

  return (
    <div style={{
      display: "flex", justifyContent: "center", alignItems: "center",
      height: "100vh", backgroundColor: "#f0f0f0"
    }}>
      <div style={{
        padding: "30px", border: "2px solid #ccc", borderRadius: "10px",
        backgroundColor: "#fff", width: "400px", boxShadow: "0 0 10px rgba(0,0,0,0.1)"
      }}>
        <h1 style={{ textAlign: "center", marginBottom: "20px" }}>Login</h1>
        <table style={{ width: "100%" }}>
          <tbody>
            <tr>
              <td>EmailId</td>
              <td><input type='text' ref={emailId} style={{ padding: "8px", width: "100%" }} /></td>
            </tr>
            <tr>
              <td>Password</td>
              <td><input type='password' ref={password} style={{ padding: "8px", width: "100%" }} /></td>
            </tr>
            <tr>
              <td></td>
              <td>
                <button onClick={loginSubmit} style={{
                  marginTop: "10px", padding: "10px 20px", width: "100%",
                  backgroundColor: "#007bff", color: "white", border: "none", borderRadius: "5px"
                }}>Login</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Login;