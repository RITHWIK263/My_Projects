import React, { Component } from 'react'
import { BrowserRouter as Router, Routes, Route, NavLink } from 'react-router-dom'
import './Header.css';

import Login from './Login'
import Register from './Register'
import ShowEmployee from './ShowEmployee'
import ShowProducts from './ShowProducts'
import Home from './Home'

export default class Header extends Component {
  render() {
    return (
      <Router>
        <div>
          <nav className='nav'>
            <a href='/'><b>Employee</b></a>&nbsp;&nbsp;&nbsp;
            <NavLink to="/home" className={({ isActive }) => isActive ? "nav-link active" : "nav-link"}>Home</NavLink>&nbsp;&nbsp;&nbsp;
            <NavLink to="/login" className={({ isActive }) => isActive ? "nav-link active" : "nav-link"}>Login</NavLink>&nbsp;&nbsp;&nbsp;
            <NavLink to="/register" className={({ isActive }) => isActive ? "nav-link active" : "nav-link"}>Register</NavLink>&nbsp;&nbsp;&nbsp;
            <NavLink to="/showemps" className={({ isActive }) => isActive ? "nav-link active" : "nav-link"}>ShowEmployees</NavLink>&nbsp;&nbsp;&nbsp;
            <NavLink to="/showproducts" className={({ isActive }) => isActive ? "nav-link active" : "nav-link"}>ShowProducts</NavLink>&nbsp;&nbsp;&nbsp;
          </nav>
          <hr />
          <br />

          <Routes>
            <Route path="/home" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/showemps" element={<ShowEmployee />} />
            <Route path="/showproducts" element={<ShowProducts />} />
          </Routes>
        </div>
      </Router>
    )
  }
}