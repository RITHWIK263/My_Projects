import React from 'react';

function Home() {
  const role = localStorage.getItem("role");
  const user = localStorage.getItem("user");

  return (
    <div>
      <h2>Welcome {role === "admin" ? "Admin (HR)" : user}</h2>
    </div>
  );
}

export default Home;