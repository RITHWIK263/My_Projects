import React, { Component } from 'react';

export default class Registration extends Component {
  constructor(props) {
    super(props);
    this.state = {
      empId: '', empName: '', salary: '', gender: '',
      doj: '', emailId: '', password: '', country: '',
      countries: [], error: '', success: ''
    };
  }

  componentDidMount() {
    fetch("https://restcountries.com/v3.1/all?fields=name,cca2,cca3")
      .then(res => res.json())
      .then(data => {
        const countryNames = data
          .map(c => c.name?.common)
          .filter(Boolean)
          .sort();
        this.setState({ countries: countryNames });
      })
      .catch(err => console.error("Failed to fetch countries:", err));
  }

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  }

  handleSubmit = (e) => {
    e.preventDefault();
    const { empId, empName, salary, gender, doj, emailId, password, country } = this.state;

    if (!empId || !empName || !salary || !gender || !doj || !emailId || !password || !country) {
      this.setState({ error: "All fields are required", success: '' });
      return;
    }

    if (localStorage.getItem(emailId)) {
      this.setState({ error: "User already registered with this EmailId", success: '' });
      return;
    }

    const user = { empId, empName, salary, gender, doj, emailId, password, country };
    localStorage.setItem(emailId, JSON.stringify(user));

    this.setState({
      success: "Registration successful!",
      error: '',
      empId: '', empName: '', salary: '', gender: '',
      doj: '', emailId: '', password: '', country: ''
    });
  }

  render() {
    const role = localStorage.getItem("role");
    if (role !== "admin") {
      return <h2 style={{ color: "red", textAlign: "center", marginTop: "50px" }}>You can't access this page</h2>;
    }

    return (
      <div style={{
        display: "flex", justifyContent: "center", alignItems: "center",
        height: "100vh", backgroundColor: "#f0f0f0"
      }}>
        <div style={{
          padding: "30px", border: "2px solid #ccc", borderRadius: "10px",
          backgroundColor: "#fff", width: "500px", boxShadow: "0 0 10px rgba(0,0,0,0.1)"
        }}>
          <h1 style={{ textAlign: "center", marginBottom: "20px" }}>Register Employee</h1>
          <form onSubmit={this.handleSubmit}>
            <table style={{ width: "100%" }}>
              <tbody>
                {["empId", "empName", "salary", "emailId", "password"].map((field) => (
                  <tr key={field}>
                    <td>{field}</td>
                    <td>
                      <input
                        type={field === "password" ? "password" : "text"}
                        name={field}
                        value={this.state[field]}
                        onChange={this.handleChange}
                        style={{ padding: "8px", width: "100%" }}
                      />
                    </td>
                  </tr>
                ))}
                <tr>
                  <td>Gender</td>
                  <td>
                    <select name="gender" value={this.state.gender} onChange={this.handleChange}
                      style={{ padding: "8px", width: "100%" }}>
                      <option value="">Select Gender</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Others">Others</option>
                    </select>
                  </td>
                </tr>
                <tr>
                  <td>Date Of Join</td>
                  <td>
                    <input type="date" name="doj" value={this.state.doj}
                      onChange={this.handleChange} style={{ padding: "8px", width: "100%" }} />
                  </td>
                </tr>
                <tr>
                  <td>Country</td>
                  <td>
                    <select name="country" value={this.state.country} onChange={this.handleChange}
                      style={{ padding: "8px", width: "100%" }}>
                      <option value="">Select Country</option>
                      {this.state.countries.map((c) => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </td>
                </tr>
                <tr>
                  <td></td>
                  <td>
                    <button type="submit" style={{
                      marginTop: "10px", padding: "10px 20px", width: "100%",
                      backgroundColor: "#28a745", color: "white", border: "none", borderRadius: "5px"
                    }}>Register</button>
                  </td>
                </tr>
                {this.state.error && (
                  <tr><td colSpan="2" style={{ color: "red", textAlign: "center" }}>{this.state.error}</td></tr>
                )}
                {this.state.success && (
                  <tr><td colSpan="2" style={{ color: "green", textAlign: "center" }}>{this.state.success}</td></tr>
                )}
              </tbody>
            </table>
          </form>
        </div>
      </div>
    );
  }
}