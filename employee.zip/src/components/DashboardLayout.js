import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';

function DashboardLayout({ children }) {
  const role = localStorage.getItem("role");
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem("role");
    localStorage.removeItem("user");
    navigate("/login");
  };

  const navStyle = {
    position: "fixed",
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#007bff",
    padding: "10px 20px",
    color: "white",
    flexWrap: "wrap",
    boxShadow: "0 2px 5px rgba(0,0,0,0.2)"
  };

  const linkContainerStyle = {
    display: "flex",
    gap: "20px",
    alignItems: "center"
  };

  const linkStyle = {
    color: "white",
    textDecoration: "none",
    fontWeight: "bold"
  };

  const logoutButtonStyle = {
    backgroundColor: "#dc3545",
    color: "white",
    border: "none",
    padding: "8px 16px",
    borderRadius: "5px",
    cursor: "pointer"
  };

  const contentStyle = {
    padding: "30px",
    marginTop: "70px" // height of the fixed nav bar
  };

  return (
    <div>
      {/* Fixed Top Navigation Bar */}
      <div style={navStyle}>
        <div style={linkContainerStyle}>
          <NavLink to="/home" style={linkStyle}>Home</NavLink>
          <NavLink to="/showproducts" style={linkStyle}>ShowProducts</NavLink>
          {role === "admin" && (
            <>
              <NavLink to="/showemployees" style={linkStyle}>ShowEmployees</NavLink>
              <NavLink to="/registration" style={linkStyle}>Registration</NavLink>
            </>
          )}
        </div>
        <button onClick={logout} style={logoutButtonStyle}>Logout</button>
      </div>

      {/* Page Content */}
      <div style={contentStyle}>
        {children}
      </div>
    </div>
  );
}

export default DashboardLayout;