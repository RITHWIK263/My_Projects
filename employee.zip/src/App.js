import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './components/Login';
import Home from './components/Home';
import ShowEmployees from './components/ShowEmployees';
import ShowProducts from './components/ShowProducts';
import Registration from './components/Registration';
import ProtectedRoute from './ProtectedRoute';
import DashboardLayout from './components/DashboardLayout';

function App() {
  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Login />} />
        <Route path="/login" element={<Login />} />

        {/* Protected Routes with Layout */}
        <Route
          path="/home"
          element={
            <ProtectedRoute>
              <DashboardLayout>
                <Home />
              </DashboardLayout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/showproducts"
          element={
            <ProtectedRoute>
              <DashboardLayout>
                <ShowProducts />
              </DashboardLayout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/showemployees"
          element={
            <ProtectedRoute>
              <DashboardLayout>
                <ShowEmployees />
              </DashboardLayout>
            </ProtectedRoute>
          }
        />
        <Route
          path="/registration"
          element={
            <ProtectedRoute>
              <DashboardLayout>
                <Registration />
              </DashboardLayout>
            </ProtectedRoute>
          }
        />
      </Routes>
    </Router>
  );
}

export default App;