import React from 'react';
import { useLocation } from 'react-router-dom';

function ProtectedRoute({ children }) {
  const role = localStorage.getItem("role");
  const location = useLocation();

  // Define access rules for each route
  const accessRules = {
    "/home": ["admin", "employee"],
    "/showproducts": ["admin", "employee"],
    "/showemployees": ["admin"]
  };

  const allowedRoles = accessRules[location.pathname];

  // If no rule is defined, allow access by default
  if (!allowedRoles) return children;

  // If role is allowed, render the page
  if (allowedRoles.includes(role)) return children;

  // Otherwise, block access
  return (
    <h2 style={{ textAlign: "center", color: "red", marginTop: "50px" }}>
      You can't access this page
    </h2>
  );
}

export default ProtectedRoute;