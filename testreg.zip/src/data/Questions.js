// src/data/questions.js
const sampleQuestions = [
  {
    text: "What is React?",
    options: ["Library", "Framework", "Language", "IDE"],
    correctAnswer: "Library"
  },
  {
    text: "Which hook is used for state management?",
    options: ["useEffect", "useState", "useContext", "useReducer"],
    correctAnswer: "useState"
  },
  {
    text: "What does JSX stand for?",
    options: [
      "JavaScript XML",
      "Java Syntax Extension",
      "JSON Syntax",
      "JavaScript Extension"
    ],
    correctAnswer: "JavaScript XML"
  }
];

export default sampleQuestions;