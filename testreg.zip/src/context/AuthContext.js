// src/context/AuthContext.jsx
import React, { createContext, useState, useEffect } from "react";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [role, setRole] = useState(null);
  const [user, setUser] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [score, setScore] = useState(null);
  const [attempts, setAttempts] = useState([]);
  const [scoreHistory, setScoreHistory] = useState([]);
  const [students, setStudents] = useState([]);
  const [theme, setTheme] = useState("light");

  useEffect(() => {
    const storedQuestions = localStorage.getItem("questions");
    const storedAttempts = localStorage.getItem("attempts");
    const storedScores = localStorage.getItem("scoreHistory");
    const storedStudents = localStorage.getItem("students");
    const storedTheme = localStorage.getItem("theme");

    if (storedQuestions) setQuestions(JSON.parse(storedQuestions));
    if (storedAttempts) setAttempts(JSON.parse(storedAttempts));
    if (storedScores) setScoreHistory(JSON.parse(storedScores));
    if (storedStudents) setStudents(JSON.parse(storedStudents));
    if (storedTheme) setTheme(storedTheme);
  }, []);

  const saveQuestions = () => {
    localStorage.setItem("questions", JSON.stringify(questions));
    alert("Questions saved successfully!");
  };

  const saveStudents = () => {
    localStorage.setItem("students", JSON.stringify(students));
    alert("Student list saved successfully!");
  };

  const registerStudent = (student) => {
    const updated = [...students, student];
    setStudents(updated);
  };

  const recordAttempt = (email) => {
    const updated = [...attempts, email];
    setAttempts(updated);
    localStorage.setItem("attempts", JSON.stringify(updated));
  };

  const recordScore = (entry) => {
    const updated = [...scoreHistory, entry];
    setScoreHistory(updated);
    localStorage.setItem("scoreHistory", JSON.stringify(updated));
  };

  const logout = () => {
    setRole(null);
    setUser(null);
    setAnswers({});
    setScore(null);
    window.location.href = "/";
  };

  const toggleTheme = () => {
    const newTheme = theme === "light" ? "dark" : "light";
    setTheme(newTheme);
    localStorage.setItem("theme", newTheme);
  };

  return (
    <AuthContext.Provider value={{
      role, setRole,
      user, setUser,
      questions, setQuestions,
      saveQuestions,
      answers, setAnswers,
      score, setScore,
      attempts,
      setAttempts, // ✅ Added to fix the error
      recordAttempt,
      scoreHistory,
      recordScore,
      students,
      registerStudent,
      saveStudents,
      theme,
      toggleTheme,
      logout
    }}>
      {children}
    </AuthContext.Provider>
  );
};