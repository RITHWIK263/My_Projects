// src/components/ThemeToggle.jsx
import React, { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

const ThemeToggle = () => {
  const { theme, toggleTheme } = useContext(AuthContext);

  return (
    <button
      onClick={toggleTheme}
      style={{
        marginBottom: "20px",
        padding: "8px",
        width: "100%",
        backgroundColor: theme === "dark" ? "#f8f9fa" : "#343a40",
        color: theme === "dark" ? "#000" : "#fff",
        border: "none",
        borderRadius: "5px",
        cursor: "pointer"
      }}
    >
      Switch to {theme === "light" ? "Dark" : "Light"} Mode
    </button>
  );
};

export default ThemeToggle;