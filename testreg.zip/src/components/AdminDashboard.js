// src/components/AdminDashboard.jsx
import React, { useContext, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import AddQuestionForm from "./AddQuestionForm";
import StudentRegisterForm from "./StudentRegisterForm";
import ThemeToggle from "./ThemeToggle";

const AdminDashboard = () => {
  const {
    questions,
    setQuestions,
    saveQuestions,
    students,
    saveStudents,
    attempts,
    setAttempts,
    user,
    logout,
    theme
  } = useContext(AuthContext);

  const [editingIndex, setEditingIndex] = useState(null);
  const [editForm, setEditForm] = useState(null);

  const resetAttempts = () => {
    setAttempts([]);
    localStorage.setItem("attempts", JSON.stringify([]));
  };

  const handleAddQuestion = (newQuestion) => {
    const updatedQuestions = [...questions, newQuestion];
    setQuestions(updatedQuestions);
    localStorage.setItem("questions", JSON.stringify(updatedQuestions));
    resetAttempts();
  };

  const handleEdit = (index) => {
    setEditingIndex(index);
    setEditForm({ ...questions[index] });
  };

  const handleUpdate = () => {
    const updated = [...questions];
    updated[editingIndex] = editForm;
    setQuestions(updated);
    localStorage.setItem("questions", JSON.stringify(updated));
    resetAttempts();
    setEditingIndex(null);
    setEditForm(null);
  };

  const handleDelete = (index) => {
    const updated = [...questions];
    updated.splice(index, 1);
    setQuestions(updated);
    localStorage.setItem("questions", JSON.stringify(updated));
    resetAttempts();
  };

  const uniqueAttempts = [...new Set(attempts)];

  return (
    <div style={{
      position: "relative",
      minHeight: "100vh",
      backgroundColor: theme === "dark" ? "#222" : "#f0f0f0",
      color: theme === "dark" ? "#fff" : "#000",
      paddingTop: "40px"
    }}>
      <button
        onClick={logout}
        style={{
          position: "absolute",
          top: "20px",
          right: "20px",
          padding: "8px 12px",
          backgroundColor: "#dc3545",
          color: "#fff",
          border: "none",
          borderRadius: "4px",
          cursor: "pointer"
        }}
      >
        Logout
      </button>

      <div style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "flex-start"
      }}>
        <div style={{
          border: "1px solid #ccc",
          borderRadius: "8px",
          padding: "20px",
          backgroundColor: theme === "dark" ? "#333" : "#fff",
          boxShadow: "0 0 10px rgba(0,0,0,0.1)",
          width: "500px"
        }}>
          <h2>Admin Dashboard</h2>
          <p>Logged in as: {user}</p>
          <ThemeToggle />

          <AddQuestionForm onAdd={handleAddQuestion} />
          <button
            onClick={saveQuestions}
            style={{
              marginBottom: "10px",
              padding: "10px",
              width: "100%",
              backgroundColor: "#28a745",
              color: "#fff",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer"
            }}
          >
            Save Questions
          </button>

          <h3>All Questions</h3>
          <ul style={{ paddingLeft: "0" }}>
            {questions.map((q, i) => (
              <li key={i} style={{
                listStyle: "none",
                marginBottom: "10px",
                padding: "10px",
                border: "1px solid #ddd",
                borderRadius: "6px"
              }}>
                {editingIndex === i ? (
                  <>
                    <input
                      type="text"
                      value={editForm.text}
                      onChange={(e) => setEditForm({ ...editForm, text: e.target.value })}
                      style={{ width: "100%", marginBottom: "5px" }}
                    />
                    {editForm.options.map((opt, idx) => (
                      <input
                        key={idx}
                        type="text"
                        value={opt}
                        onChange={(e) => {
                          const updated = [...editForm.options];
                          updated[idx] = e.target.value;
                          setEditForm({ ...editForm, options: updated });
                        }}
                        style={{ width: "100%", marginBottom: "5px" }}
                      />
                    ))}
                    <input
                      type="text"
                      value={editForm.correctAnswer}
                      onChange={(e) => setEditForm({ ...editForm, correctAnswer: e.target.value })}
                      style={{ width: "100%", marginBottom: "5px" }}
                    />
                    <button
                      onClick={handleUpdate}
                      style={{
                        padding: "6px",
                        backgroundColor: "#007bff",
                        color: "#fff",
                        border: "none",
                        borderRadius: "4px",
                        cursor: "pointer"
                      }}
                    >
                      Update
                    </button>
                  </>
                ) : (
                  <>
                    <strong>{i + 1}. {q.text}</strong>
                    <ul style={{ paddingLeft: "20px", marginTop: "5px" }}>
                      {q.options.map((opt, idx) => (
                        <li key={idx}>{opt}</li>
                      ))}
                    </ul>
                    <p><strong>Correct Answer:</strong> {q.correctAnswer}</p>
                    <button
                      onClick={() => handleEdit(i)}
                      style={{
                        padding: "6px",
                        backgroundColor: "#ffc107",
                        color: "#000",
                        border: "none",
                        borderRadius: "4px",
                        cursor: "pointer",
                        marginRight: "10px"
                      }}
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(i)}
                      style={{
                        padding: "6px",
                        backgroundColor: "#dc3545",
                        color: "#fff",
                        border: "none",
                        borderRadius: "4px",
                        cursor: "pointer"
                      }}
                    >
                      Delete
                    </button>
                  </>
                )}
              </li>
            ))}
            {questions.length === 0 && <p>No questions added yet.</p>}
          </ul>

          <StudentRegisterForm />
          <button
            onClick={saveStudents}
            style={{
              marginBottom: "20px",
              padding: "10px",
              width: "100%",
              backgroundColor: "#6c757d",
              color: "#fff",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer"
            }}
          >
            Save Student List
          </button>

          <h3>Registered Students</h3>
          <ul>
            {students.map((s, i) => (
              <li key={i}>
                {s.name} — {s.email}
              </li>
            ))}
          </ul>

          <h3>Student Attempts: {uniqueAttempts.length}</h3>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;