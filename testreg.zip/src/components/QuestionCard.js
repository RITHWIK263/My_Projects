// src/components/QuestionCard.jsx
import React, { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

const QuestionCard = ({ question, index, selected, handleAnswer }) => {
  const { theme } = useContext(AuthContext);

  return (
    <div style={{
      marginBottom: "15px",
      padding: "10px",
      border: "1px solid #ddd",
      borderRadius: "6px",
      backgroundColor: theme === "dark" ? "#444" : "#fff",
      color: theme === "dark" ? "#fff" : "#000"
    }}>
      <h4>{index + 1}. {question.text}</h4>
      {question.options.map((opt, i) => {
        const isSelected = selected === opt;
        return (
          <button
            key={i}
            onClick={() => handleAnswer(index, opt)}
            style={{
              display: "block",
              margin: "5px 0",
              padding: "8px",
              width: "100%",
              backgroundColor: isSelected ? "#007bff" : "#eee",
              color: isSelected ? "#fff" : "#000",
              border: "1px solid #ccc",
              borderRadius: "4px",
              cursor: "pointer"
            }}
          >
            {opt}
          </button>
        );
      })}
    </div>
  );
};

export default QuestionCard;