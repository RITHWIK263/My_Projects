// src/components/ExamPage.jsx
import React, { useContext, useEffect, useState, useCallback, useRef } from "react";
import { AuthContext } from "../context/AuthContext";
import QuestionCard from "./QuestionCard";

const ExamPage = () => {
  const {
    questions,
    answers,
    setAnswers,
    score,
    setScore,
    user,
    logout,
    recordAttempt,
    recordScore,
    theme
  } = useContext(AuthContext);

  const [timeLeft, setTimeLeft] = useState(60);
  const [submitted, setSubmitted] = useState(false);
  const [timeTaken, setTimeTaken] = useState(0);
  const [currentIndex, setCurrentIndex] = useState(0);
  const timerRef = useRef(null);

  const submitExam = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    let calculatedScore = 0;
    questions.forEach((q, i) => {
      if (answers[i] === q.correctAnswer) calculatedScore++;
    });
    setScore(calculatedScore);
    setTimeTaken(60 - timeLeft);
    setSubmitted(true);
    recordAttempt(user);
    recordScore({
      email: user,
      score: calculatedScore,
      timeTaken: 60 - timeLeft,
      date: new Date().toISOString()
    });
  }, [answers, questions, setScore, timeLeft, user, recordAttempt, recordScore]);

  useEffect(() => {
    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev === 1) {
          clearInterval(timerRef.current);
          submitExam();
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timerRef.current);
  }, [submitExam]);

  const handleAnswer = (index, selected) => {
    setAnswers({ ...answers, [index]: selected });
  };

  const nextQuestion = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const prevQuestion = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  return (
    <div style={{
      position: "relative",
      minHeight: "100vh",
      backgroundColor: theme === "dark" ? "#222" : "#f0f0f0",
      paddingTop: "40px",
      color: theme === "dark" ? "#fff" : "#000"
    }}>
      {!submitted && (
        <button
          onClick={logout}
          style={{
            position: "absolute",
            top: "20px",
            right: "20px",
            padding: "8px 12px",
            backgroundColor: "#dc3545",
            color: "#fff",
            border: "none",
            borderRadius: "4px",
            cursor: "pointer"
          }}
        >
          Logout
        </button>
      )}
      <div style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "flex-start"
      }}>
        <div style={{
          border: "1px solid #ccc",
          borderRadius: "8px",
          padding: "20px",
          backgroundColor: theme === "dark" ? "#333" : "#fff",
          boxShadow: "0 0 10px rgba(0,0,0,0.1)",
          width: "500px"
        }}>
          <h2>Exam Page</h2>
          {!submitted && <p>Time Remaining: {timeLeft}s</p>}
          {submitted && <p>Total Time Taken: {timeTaken}s</p>}

          {!submitted ? (
            <>
              <QuestionCard
                question={questions[currentIndex]}
                index={currentIndex}
                selected={answers[currentIndex]}
                handleAnswer={handleAnswer}
              />
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: "10px" }}>
                <button
                  onClick={prevQuestion}
                  disabled={currentIndex === 0}
                  style={{
                    padding: "8px",
                    backgroundColor: "#6c757d",
                    color: "#fff",
                    border: "none",
                    borderRadius: "4px",
                    cursor: currentIndex === 0 ? "not-allowed" : "pointer"
                  }}
                >
                  Previous
                </button>
                {currentIndex < questions.length - 1 ? (
                  <button
                    onClick={nextQuestion}
                    style={{
                      padding: "8px",
                      backgroundColor: "#007bff",
                      color: "#fff",
                      border: "none",
                      borderRadius: "4px",
                      cursor: "pointer"
                    }}
                  >
                    Next
                  </button>
                ) : (
                  <button
                    onClick={submitExam}
                    style={{
                      padding: "8px",
                      backgroundColor: "#28a745",
                      color: "#fff",
                      border: "none",
                      borderRadius: "4px",
                      cursor: "pointer"
                    }}
                  >
                    Submit
                  </button>
                )}
              </div>
            </>
          ) : (
            <>
              <h3>Your Score: {score} / {questions.length}</h3>
              <p>Attempt recorded for: <strong>{user}</strong></p>
              <hr />
              <h4>Review Your Answers:</h4>
              {questions.map((q, i) => {
                const selected = answers[i];
                const correct = q.correctAnswer;
                const isCorrect = selected === correct;
                return (
                  <div key={i} style={{
                    marginBottom: "15px",
                    padding: "10px",
                    border: "1px solid #ddd",
                    borderRadius: "6px",
                    backgroundColor: isCorrect ? "#d4edda" : "#f8d7da",
                    color: isCorrect ? "#155724" : "#721c24"
                  }}>
                    <strong>{i + 1}. {q.text}</strong>
                    <p><strong>Your Answer:</strong> {selected || "Not answered"}</p>
                    <p><strong>Correct Answer:</strong> {correct}</p>
                  </div>
                );
              })}
              <button
                onClick={logout}
                style={{
                  marginTop: "20px",
                  padding: "10px",
                  width: "100%",
                  backgroundColor: "#dc3545",
                  color: "#fff",
                  border: "none",
                  borderRadius: "4px",
                  cursor: "pointer"
                }}
              >
                Logout
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default ExamPage;