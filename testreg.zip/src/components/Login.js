// src/components/Login.jsx
import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

const credentials = {
  admin: { email: "admin@example.com", password: "admin123" }
};

const Login = () => {
  const { setRole, setUser, students, theme } = useContext(AuthContext);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [selectedRole, setSelectedRole] = useState("student");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = () => {
    if (selectedRole === "admin") {
      const valid = credentials.admin;
      if (email === valid.email && password === valid.password) {
        setRole("admin");
        setUser(email);
        navigate("/admin");
        return;
      }
    } else {
      const found = students.find(s => s.email === email && s.password === password);
      if (found) {
        setRole("student");
        setUser(email);
        navigate("/student");
        return;
      }
    }
    setError("Invalid email or password");
  };

  return (
    <div style={{
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      height: "100vh",
      backgroundColor: theme === "dark" ? "#222" : "#f0f2f5"
    }}>
      <div style={{
        border: "1px solid #ccc",
        borderRadius: "10px",
        padding: "30px",
        backgroundColor: theme === "dark" ? "#333" : "#fff",
        boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
        width: "320px",
        textAlign: "center",
        color: theme === "dark" ? "#fff" : "#000"
      }}>
        <h2>Login</h2>
        <select
          value={selectedRole}
          onChange={(e) => setSelectedRole(e.target.value)}
          style={{
            marginBottom: "15px",
            padding: "8px",
            width: "100%",
            borderRadius: "5px",
            border: "1px solid #ccc"
          }}
        >
          <option value="student">Student</option>
          <option value="admin">Admin</option>
        </select>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          style={{
            marginBottom: "15px",
            padding: "8px",
            width: "100%",
            borderRadius: "5px",
            border: "1px solid #ccc"
          }}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          style={{
            marginBottom: "15px",
            padding: "8px",
            width: "100%",
            borderRadius: "5px",
            border: "1px solid #ccc"
          }}
        />
        <button
          onClick={handleLogin}
          style={{
            padding: "10px",
            width: "100%",
            backgroundColor: "#007bff",
            color: "#fff",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer"
          }}
        >
          Login
        </button>
        {error && <p style={{ color: "red", marginTop: "15px" }}>{error}</p>}
      </div>
    </div>
  );
};

export default Login;