// src/components/AddQuestionForm.jsx
import React, { useContext, useState } from "react";
import { AuthContext } from "../context/AuthContext";

const AddQuestionForm = ({ onAdd }) => {
  const { theme } = useContext(AuthContext);
  const [form, setForm] = useState({
    text: "",
    options: ["", "", "", ""],
    correctAnswer: ""
  });

  const handleChange = (e, index) => {
    const newOptions = [...form.options];
    newOptions[index] = e.target.value;
    setForm({ ...form, options: newOptions });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onAdd(form);
    setForm({ text: "", options: ["", "", "", ""], correctAnswer: "" });
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: "20px" }}>
      <h3>Add New Question</h3>
      <input
        type="text"
        placeholder="Question"
        value={form.text}
        onChange={(e) => setForm({ ...form, text: e.target.value })}
        required
        style={{
          marginBottom: "10px",
          padding: "8px",
          width: "100%",
          borderRadius: "5px",
          border: "1px solid #ccc",
          backgroundColor: theme === "dark" ? "#444" : "#fff",
          color: theme === "dark" ? "#fff" : "#000"
        }}
      />
      {form.options.map((opt, i) => (
        <input
          key={i}
          type="text"
          placeholder={`Option ${i + 1}`}
          value={opt}
          onChange={(e) => handleChange(e, i)}
          required
          style={{
            marginBottom: "10px",
            padding: "8px",
            width: "100%",
            borderRadius: "5px",
            border: "1px solid #ccc",
            backgroundColor: theme === "dark" ? "#444" : "#fff",
            color: theme === "dark" ? "#fff" : "#000"
          }}
        />
      ))}
      <input
        type="text"
        placeholder="Correct Answer"
        value={form.correctAnswer}
        onChange={(e) => setForm({ ...form, correctAnswer: e.target.value })}
        required
        style={{
          marginBottom: "10px",
          padding: "8px",
          width: "100%",
          borderRadius: "5px",
          border: "1px solid #ccc",
          backgroundColor: theme === "dark" ? "#444" : "#fff",
          color: theme === "dark" ? "#fff" : "#000"
        }}
      />
      <button
        type="submit"
        style={{
          padding: "10px",
          width: "100%",
          backgroundColor: "#28a745",
          color: "#fff",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer"
        }}
      >
        Add Question
      </button>
    </form>
  );
};

export default AddQuestionForm;