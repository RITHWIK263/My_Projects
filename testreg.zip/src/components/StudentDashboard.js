// src/components/StudentDashboard.jsx
import React, { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import ThemeToggle from "./ThemeToggle";

const StudentDashboard = () => {
  const { user, logout, setAnswers, setScore, theme } = useContext(AuthContext);
  const navigate = useNavigate();

  const startExam = () => {
    setAnswers({});
    setScore(null);
    navigate("/exam");
  };

  return (
    <div style={{
      position: "relative",
      height: "100vh",
      backgroundColor: theme === "dark" ? "#222" : "#f0f0f0",
      color: theme === "dark" ? "#fff" : "#000"
    }}>
      <button
        onClick={logout}
        style={{
          position: "absolute",
          top: "20px",
          right: "20px",
          padding: "8px 12px",
          backgroundColor: "#dc3545",
          color: "#fff",
          border: "none",
          borderRadius: "4px",
          cursor: "pointer"
        }}
      >
        Logout
      </button>
      <div style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "100%"
      }}>
        <div style={{
          border: "1px solid #ccc",
          borderRadius: "8px",
          padding: "20px",
          backgroundColor: theme === "dark" ? "#333" : "#fff",
          boxShadow: "0 0 10px rgba(0,0,0,0.1)",
          width: "300px",
          textAlign: "center"
        }}>
          <h2>Student Dashboard</h2>
          <p>Logged in as: {user}</p>
          <ThemeToggle />
          <button
            onClick={startExam}
            style={{
              padding: "10px",
              width: "100%",
              backgroundColor: "#28a745",
              color: "#fff",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer"
            }}
          >
            Start Exam
          </button>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;