// src/components/StudentRegisterForm.jsx
import React, { useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";

const StudentRegisterForm = () => {
  const { registerStudent, theme } = useContext(AuthContext);
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: ""
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    registerStudent(form);
    setForm({ name: "", email: "", password: "" });
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: "20px" }}>
      <h3>Register New Student</h3>
      <input
        type="text"
        placeholder="Name"
        value={form.name}
        onChange={(e) => setForm({ ...form, name: e.target.value })}
        required
        style={{
          marginBottom: "10px",
          padding: "8px",
          width: "100%",
          borderRadius: "5px",
          border: "1px solid #ccc",
          backgroundColor: theme === "dark" ? "#444" : "#fff",
          color: theme === "dark" ? "#fff" : "#000"
        }}
      />
      <input
        type="email"
        placeholder="Email"
        value={form.email}
        onChange={(e) => setForm({ ...form, email: e.target.value })}
        required
        style={{
          marginBottom: "10px",
          padding: "8px",
          width: "100%",
          borderRadius: "5px",
          border: "1px solid #ccc",
          backgroundColor: theme === "dark" ? "#444" : "#fff",
          color: theme === "dark" ? "#fff" : "#000"
        }}
      />
      <input
        type="password"
        placeholder="Password"
        value={form.password}
        onChange={(e) => setForm({ ...form, password: e.target.value })}
        required
        style={{
          marginBottom: "10px",
          padding: "8px",
          width: "100%",
          borderRadius: "5px",
          border: "1px solid #ccc",
          backgroundColor: theme === "dark" ? "#444" : "#fff",
          color: theme === "dark" ? "#fff" : "#000"
        }}
      />
      <button
        type="submit"
        style={{
          padding: "10px",
          width: "100%",
          backgroundColor: "#17a2b8",
          color: "#fff",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer"
        }}
      >
        Register Student
      </button>
    </form>
  );
};

export default StudentRegisterForm;