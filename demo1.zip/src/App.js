import './App.css';
// import Main from './components/Main';
import Parent from './components/Parent';

function App() {
  return (
  //   <div>
  //     <h1>welcome to my site</h1>
  //     // <Main />
  //   </div>
  <Parent></Parent>
  );
}

export default App;