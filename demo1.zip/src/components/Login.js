import React, { useState } from "react";
import Header from "../components/Header";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("user");

  const handleLogin = (e) => {
    e.preventDefault();
    alert(`Login attempted for ${role} with ${email}`);
  };

  return (
    <>
      <Header title="Login" />
      <div
        style={{
          padding: "40px 20px",
          textAlign: "center",
          backgroundColor: "#f7f7f7",
          minHeight: "calc(100vh - 120px)",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <form
          onSubmit={handleLogin}
          style={{
            backgroundColor: "#fff",
            padding: "30px",
            borderRadius: "10px",
            boxShadow: "0 3px 10px rgba(0,0,0,0.1)",
            width: "100%",
            maxWidth: "400px",
            textAlign: "left",
          }}
        >
          <h2 style={{ textAlign: "center", marginBottom: "20px", color: "#4a90e2" }}>Login</h2>

          <label style={labelStyle}>
            Role:
            <select
              value={role}
              onChange={(e) => setRole(e.target.value)}
              style={inputStyle}
            >
              <option value="user">User</option>
              <option value="owner">Owner</option>
            </select>
          </label>

          <label style={labelStyle}>
            Email:
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={inputStyle}
            />
          </label>

          <label style={labelStyle}>
            Password:
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={inputStyle}
            />
          </label>

          <div style={{ textAlign: "center", marginTop: "20px" }}>
            <button type="submit" style={buttonStyle}>Login</button>
          </div>
        </form>
      </div>
    </>
  );
};

const labelStyle = {
  display: "block",
  marginBottom: "15px",
  fontWeight: "500",
  color: "#333",
};

const inputStyle = {
  width: "100%",
  padding: "10px",
  marginTop: "6px",
  border: "1px solid #ccc",
  borderRadius: "6px",
  boxSizing: "border-box",
};

const buttonStyle = {
  padding: "10px 20px",
  backgroundColor: "#4a90e2",
  color: "#fff",
  border: "none",
  borderRadius: "6px",
  cursor: "pointer",
  fontWeight: "bold",
  transition: "background-color 0.3s ease",
};

export default Login;