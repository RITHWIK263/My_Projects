import React from "react";

function Header() {
  return (
    <div style={{
      width: "100%",
      padding: "20px 0",
      background: "#4A90E2",
      color: "white",
      textAlign: "center",
      fontSize: "2rem",
      fontWeight: "bold",
      letterSpacing: "2px",
      borderBottom: "3px solid #357ABD"
    }}>
      Registration Form
    </div>
  );
}

export default Header;