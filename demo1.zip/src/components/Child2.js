const Child2 = ({text, setText}) => {
  return (
    <div>
      <label>Child2</label>
      <input
        type="text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Type in B"
      />
    </div>
  )
}
export default Child2;