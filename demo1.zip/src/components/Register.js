import React, { useState } from "react";
import Header from "../components/Header";

const Register = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    role: "user",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleRegister = (e) => {
    e.preventDefault();
    alert(`Registration attempted for ${formData.role} with ${formData.email}`);
  };

  return (
    <>
      <Header />
      <div
        style={{
          padding: "40px 20px",
          textAlign: "center",
          backgroundColor: "#f7f7f7",
          minHeight: "calc(100vh - 120px)",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <form
          onSubmit={handleRegister}
          style={{
            backgroundColor: "#fff",
            padding: "30px",
            borderRadius: "10px",
            boxShadow: "0 3px 10px rgba(0,0,0,0.1)",
            width: "100%",
            maxWidth: "420px",
            textAlign: "left",
          }}
        >
          <h2 style={{ textAlign: "center", marginBottom: "20px", color: "#4a90e2" }}>Register</h2>

          <label style={labelStyle}>
            Role:
            <select
              name="role"
              value={formData.role}
              onChange={handleChange}
              style={inputStyle}
            >
              <option value="user">User</option>
              <option value="owner">Owner</option>
            </select>
          </label>

          <label style={labelStyle}>
            Name:
            <input
              type="text"
              name="name"
              required
              value={formData.name}
              onChange={handleChange}
              style={inputStyle}
            />
          </label>

          <label style={labelStyle}>
            Email:
            <input
              type="email"
              name="email"
              required
              value={formData.email}
              onChange={handleChange}
              style={inputStyle}
            />
          </label>

          <label style={labelStyle}>
            Password:
            <input
              type="password"
              name="password"
              required
              value={formData.password}
              onChange={handleChange}
              style={inputStyle}
            />
          </label>

          <div style={{ textAlign: "center", marginTop: "20px" }}>
            <button type="submit" style={buttonStyle}>Register</button>
          </div>
        </form>
      </div>
    </>
  );
};

const labelStyle = {
  display: "block",
  marginBottom: "15px",
  fontWeight: "500",
  color: "#333",
};

const inputStyle = {
  width: "100%",
  padding: "10px",
  marginTop: "6px",
  border: "1px solid #ccc",
  borderRadius: "6px",
  boxSizing: "border-box",
};

const buttonStyle = {
  padding: "10px 20px",
  backgroundColor: "#4a90e2",
  color: "#fff",
  border: "none",
  borderRadius: "6px",
  cursor: "pointer",
  fontWeight: "bold",
  transition: "background-color 0.3s ease",
};

export default Register;