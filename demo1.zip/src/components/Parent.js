import React, {useState} from "react";
import Child1 from "./Child1";
import Child2 from "./Child2";

function Parent() {
  const [text, setText] = useState("");

  return (
    <div>
      <h1>Lifting State Example</h1>
      <Child1 text={text} setText={setText} />
      <Child2 text={text} setText={setText} />
      <p>Shared Text: {text}</p>
    </div>
  );
}
export default Parent;