import React from "react";

const containerStyle = {
  border: "2px solid #4A90E2",
  borderRadius: "15px",
  padding: "30px",
  width: "400px",
  margin: "50px auto",
  backgroundColor: "#E8F0FE",
  boxShadow: "0 8px 16px rgba(0, 0, 0, 0.2)",
  fontFamily: "Arial, sans-serif"
};

const headingStyle = {
  textAlign: "center",
  color: "#2C3E50",
  marginBottom: "25px"
};

function AboutUs() {
  return (
    <div style={containerStyle}>
      <h2 style={headingStyle}>Registration Form</h2>
      <p>
        Welcome to our website! We are dedicated to providing the best service and experience for our users.
        Please register to get started and enjoy all our features.
      </p>
    </div>
  );
}

export default AboutUs;