import { Component } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from "./Home";
import Login from "./Login";
import AboutUs from "./AboutUs";
import Register from "./Register"; // Added missing import

export default class Main extends Component {
    render() {
        return (
            <Router>
                <div>
                    <Link to="/home">Home</Link>{" "}
                    <Link to="/login">Login</Link>{" "}
                    <Link to="/aboutus">About Us</Link>{" "}
                    <Link to="/register">Register</Link>{" "} {/* Fixed casing */}
                    
                    <hr />
                    <br />
                    <h1 style={{ textAlign: "center" }}>Welcome to KING'S CHOICE</h1> {/* Removed <marquee> */}
                    <br />
                    <hr />
                    <Routes>
                        <Route path="/home" element={<Home />} />
                        <Route path="/login" element={<Login />} />
                        <Route path="/aboutus" element={<AboutUs />} />
                        <Route path="/register" element={<Register />} /> {/* Fixed casing */}
                        {/* Add more routes as needed */}
                    </Routes>
                </div>
            </Router>
        );
    }
}