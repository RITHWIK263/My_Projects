import React from "react";

const VehicleCard = ({ vehicle }) => {
  return (
    <div
      style={{
        border: "1px solid #ddd",
        padding: "16px",
        marginBottom: "16px",
        borderRadius: "8px",
        boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
        backgroundColor: "#ffffff",
        maxWidth: "400px",
        margin: "0 auto",
        textAlign: "center",
      }}
    >
      <h3 style={{ color: "#4a90e2", marginBottom: "10px" }}>{vehicle.model}</h3>
      <p>Type: <strong>{vehicle.type}</strong></p>
      <p>Mileage: <strong>{vehicle.mileage}</strong></p>
      <p>Condition: <strong>{vehicle.condition}</strong></p>
      <p>Status:{" "}
        <span style={{ color: vehicle.available ? "green" : "red" }}>
          {vehicle.available ? "Available" : "Not Available"}
        </span>
      </p>
      <button
        disabled={!vehicle.available}
        style={{
          marginTop: "12px",
          padding: "8px 16px",
          border: "none",
          borderRadius: "4px",
          backgroundColor: vehicle.available ? "#4a90e2" : "#ccc",
          color: "#fff",
          cursor: vehicle.available ? "pointer" : "not-allowed",
        }}
      >
        Book Now
      </button>
    </div>
  );
};

export default VehicleCard;