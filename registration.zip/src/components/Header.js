import React from "react";
import { Link } from "react-router-dom";

const Header = () => {
  return (
    <header
      style={{
        padding: "20px",
        background: "#4a90e2",
        marginBottom: "20px",
        borderBottom: "2px solid #357ABD",
        boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
        textAlign: "center",
        color: "#fff",
      }}
    >
      <h2 style={{ marginBottom: "10px" }}>VehicleRent</h2>
      <nav style={{ display: "inline-flex", gap: "12px", flexWrap: "wrap", justifyContent: "center" }}>
        <Link to="/" style={linkStyle}>Home</Link>
        <Link to="/login" style={linkStyle}>Login</Link>
        <Link to="/register" style={linkStyle}>Register</Link>
        <Link to="/vehicles" style={linkStyle}>Vehicles</Link>
        <Link to="/owner" style={linkStyle}>Owner Dashboard</Link>
      </nav>
    </header>
  );
};

const linkStyle = {
  padding: "8px 14px",
  border: "1px solid transparent",
  borderRadius: "6px",
  textDecoration: "none",
  backgroundColor: "#ffffff",
  color: "#4a90e2",
  fontWeight: "500",
  transition: "all 0.2s ease-in-out",
  boxShadow: "1px 1px 4px rgba(0,0,0,0.1)",
};

export default Header;