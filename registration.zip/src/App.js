// import logo from './logo.svg';
import './App.css';

import React from "react";
// import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import VehicleList from "./pages/VehicleList";
import OwnerDashboard from './pages/OwnerDashBoard';
import VehicleCard from './components/VehicleCard';
import Header from './components/Header';

function App() {
  return (
    <div className="App">
      <h1>Welcome to VehicleRent</h1>
          <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/vehicles" element={<VehicleList />} />
        <Route path="/owner" element={<OwnerDashboard />} />
        <Route path="/" element={<VehicleCard />} />
        <Route path="/" element={<Header />} />
      </Routes>
    </Router>
   
    </div>
  );
}

export default App;