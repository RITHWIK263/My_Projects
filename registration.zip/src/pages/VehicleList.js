import React, { useState, useEffect } from "react";
import Header from "../components/Header";
import VehicleCard from "../components/VehicleCard";

const VehicleList = () => {
  const [vehicles, setVehicles] = useState([]);

  useEffect(() => {
    const dummyData = [
      {
        id: 1,
        model: "Honda Activa",
        type: "2-wheeler",
        mileage: "40kmpl",
        condition: "Good",
        available: true,
      },
      {
        id: 2,
        model: "Hyundai i10",
        type: "4-wheeler",
        mileage: "18kmpl",
        condition: "Excellent",
        available: false,
      },
      {
        id: 3,
        model: "Royal Enfield Classic 350",
        type: "2-wheeler",
        mileage: "35kmpl",
        condition: "Very Good",
        available: true,
      },
      {
        id: 4,
        model: "Maruti Swift",
        type: "4-wheeler",
        mileage: "22kmpl",
        condition: "Good",
        available: true,
      },
      {
        id: 5,
        model: "Bajaj Pulsar 220F",
        type: "2-wheeler",
        mileage: "38kmpl",
        condition: "Like New",
        available: false,
      },
      {
        id: 6,
        model: "Toyota Innova Crysta",
        type: "4-wheeler",
        mileage: "15kmpl",
        condition: "Excellent",
        available: true,
      },
    ];
    setVehicles(dummyData);
  }, []);

  return (
    <>
      <Header />
      <div
        style={{
          padding: "40px 20px",
          backgroundColor: "#f9f9f9",
          minHeight: "calc(100vh - 120px)",
        }}
      >
        <h2
          style={{
            textAlign: "center",
            color: "#4a90e2",
            marginBottom: "30px",
          }}
        >
          Available Vehicles
        </h2>
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            justifyContent: "center",
            gap: "20px",
          }}
        >
          {vehicles.map((v) => (
            <VehicleCard key={v.id} vehicle={v} />
          ))}
        </div>
      </div>
    </>
  );
};

export default VehicleList;