import React from "react";
import Header from "../components/Header";

const Home = () => {
  return (
    <>
      <Header />
      <div
        style={{
          padding: "40px 20px",
          textAlign: "center",
          backgroundColor: "#f9f9f9",
          minHeight: "calc(100vh - 120px)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <h1 style={{ color: "#4a90e2", fontSize: "2.5rem", marginBottom: "16px" }}>
          Welcome to <span style={{ fontWeight: "bold" }}>VehicleRent</span>
        </h1>
        <p style={{ fontSize: "1.2rem", color: "#444", maxWidth: "600px" }}>
          Rent 2-wheelers and 4-wheelers easily from anywhere — fast, affordable, and hassle-free.
        </p>
      </div>
    </>
  );
};

export default Home;