import React from "react";
import Header from "../components/Header";

const OwnerDashBoard = () => {
  return (
    <>
      <Header />
      <div
        style={{
          padding: "40px 20px",
          textAlign: "center",
          backgroundColor: "#f7f7f7",
          minHeight: "calc(100vh - 120px)",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <div
          style={{
            backgroundColor: "#fff",
            padding: "30px",
            borderRadius: "10px",
            boxShadow: "0 3px 10px rgba(0,0,0,0.1)",
            width: "100%",
            maxWidth: "500px",
            textAlign: "left",
          }}
        >
          <h2 style={{ textAlign: "center", color: "#4a90e2", marginBottom: "15px" }}>
            Owner Dashboard
          </h2>
          <p style={{ fontSize: "1.1rem", color: "#444" }}>
            This page will let owners <strong>add</strong>, <strong>update</strong>, and <strong>delete</strong> their vehicles.
          </p>
          {/* Add form and list later */}
        </div>
      </div>
    </>
  );
};

export default OwnerDashBoard;