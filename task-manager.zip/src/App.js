// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { TaskProvider } from './context/TaskContext';
import Header from './components/Headers';
import Home from './pages/Home';
import About from './pages/About';
import TaskForm from './components/TaskForm';
import TaskList from './components/TaskList';

function App() {
  return (
    <TaskProvider>
      <Router>
        <div style={styles.container}>
          <Header />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/tasks" element={
              <>
                <h2> Task Manager</h2>
                <TaskForm />
                <TaskList />
              </>
            } />
            <Route path="/about" element={<About />} />
          </Routes>
        </div>
      </Router>
    </TaskProvider>
  );
}

const styles = {
  container: {
    maxWidth: '600px',
    margin: '40px auto',
    padding: '20px',
    border: '2px solid #ccc',
    borderRadius: '10px',
    backgroundColor: '#f9f9f9',
    fontFamily: 'Arial, sans-serif'
  }
};

export default App;