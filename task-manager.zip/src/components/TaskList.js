// src/components/TaskList.js
import React, { useContext, useState } from 'react';
import { TaskContext } from '../context/TaskContext';

function TaskList() {
  const { tasks, deleteTask, editTask } = useContext(TaskContext);
  const [editingId, setEditingId] = useState(null);
  const [newText, setNewText] = useState('');
  const [newTime, setNewTime] = useState('');

  const startEdit = (task) => {
    setEditingId(task.id);
    setNewText(task.text);
    setNewTime(task.time);
  };

  const saveEdit = () => {
    editTask(editingId, newText, newTime);
    setEditingId(null);
  };

  const testAlarm = () => {
    console.log("🔔 Test button clicked");
    const audio = new Audio('/alarm.mp3');
    audio.play()
      .then(() => {
        console.log("✅ Sound played successfully");
      })
      .catch(err => {
        console.error("❌ Sound failed to play:", err);
      });
  };

  return (
    <div>
      <ul>
        {tasks.map(task => (
          <li key={task.id}>
            {editingId === task.id ? (
              <>
                <input
                  value={newText}
                  onChange={(e) => setNewText(e.target.value)}
                />
                <input
                  type="time"
                  value={newTime}
                  onChange={(e) => setNewTime(e.target.value)}
                />
                <button onClick={saveEdit}>💾 Save</button>
                <button onClick={() => setEditingId(null)}>❌ Cancel</button>
              </>
            ) : (
              <>
                {task.text} — <strong>{task.time}</strong>
                <button onClick={() => startEdit(task)}>✏️ Edit</button>
                <button onClick={() => deleteTask(task.id)}>🗑️ Delete</button>
              </>
            )}
          </li>
        ))}
      </ul>

      <hr />
      <button onClick={testAlarm}>🔊 Test Alarm Sound</button>
    </div>
  );
}

export default TaskList;