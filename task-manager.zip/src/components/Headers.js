import React from 'react';
import { Link, useLocation } from 'react-router-dom';

function Header() {
  const location = useLocation();

  const linkStyle = (path) => ({
    textDecoration: 'none',
    color: location.pathname === path ? '#000' : '#007bff',
    fontWeight: location.pathname === path ? 'bold' : 'normal',
    borderBottom: location.pathname === path ? '2px solid #007bff' : 'none',
    padding: '5px 10px'
  });

  return (
    <nav style={styles.nav}>
      <Link to="/" style={linkStyle('/')}>Home</Link>
      <Link to="/tasks" style={linkStyle('/tasks')}>Tasks</Link>
      <Link to="/about" style={linkStyle('/about')}>About</Link>
    </nav>
  );
}

const styles = {
  nav: {
    display: 'flex',
    justifyContent: 'center',
    gap: '20px',
    marginBottom: '20px'
  }
};

export default Header;