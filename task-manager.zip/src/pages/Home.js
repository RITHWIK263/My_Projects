import React from 'react';

function Home() {
  return (
    <div>
      <h2> Welcome</h2>
      <p>This is your personal task manager with alarms. Navigate to Tasks to get started!</p>
    </div>
  );
}

export default Home;