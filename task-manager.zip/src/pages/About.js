import React from 'react';

function About() {
  return (
    <div>
      <h2>ℹ About This App</h2>
      <p>This app lets you create tasks with time-based alarms. Built with React by Rithwik </p>
    </div>
  );
}

export default About;