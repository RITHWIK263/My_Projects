// src/context/TaskContext.js
import React, { createContext, useState, useEffect } from 'react';

export const TaskContext = createContext();

export const TaskProvider = ({ children }) => {
  const [tasks, setTasks] = useState([]);

  const addTask = (text, time) => {
    const newTask = {
      id: Date.now(),
      text,
      time,
      notified: false
    };
    setTasks(prev => [...prev, newTask]);
  };

  const deleteTask = (id) => {
    setTasks(prev => prev.filter(task => task.id !== id));
  };

  const editTask = (id, newText, newTime) => {
    setTasks(prev =>
      prev.map(task =>
        task.id === id ? { ...task, text: newText, time: newTime, notified: false } : task
      )
    );
  };

  const playAlarm = () => {
    console.log("🔔 Alarm triggered!");
    const audio = new Audio('/alarm.mp3');
    audio.play()
      .then(() => {
        console.log("✅ Alarm sound played");
      })
      .catch(err => {
        console.error("❌ Error playing alarm sound:", err);
      });
  };

  useEffect(() => {
    const stored = localStorage.getItem('tasks');
    if (stored) {
      setTasks(JSON.parse(stored));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    const checkAlarms = setInterval(() => {
      const now = new Date();
      const currentTime = now.toTimeString().slice(0, 5); // "HH:mm"

      setTasks(prev =>
        prev.map(task => {
          if (task.time === currentTime && !task.notified) {
            playAlarm();
            return { ...task, notified: true };
          }
          return task;
        })
      );
    }, 60000); // check every minute

    return () => clearInterval(checkAlarms);
  }, []);

  return (
    <TaskContext.Provider value={{ tasks, addTask, deleteTask, editTask }}>
      {children}
    </TaskContext.Provider>
  );
};