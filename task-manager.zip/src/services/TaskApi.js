const API_URL = 'https://jsonplaceholder.typicode.com/todos';

export async function getTasks() {
  const res = await fetch(API_URL + '?_limit=5');
  const data = await res.json();
  return data.map(t => ({ id: t.id, text: t.title }));
}

export async function addTaskAPI(task) {
  const res = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title: task.text })
  });
  const data = await res.json();
  return { id: data.id, text: data.title };
}

export async function deleteTaskAPI(id) {
  await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
}